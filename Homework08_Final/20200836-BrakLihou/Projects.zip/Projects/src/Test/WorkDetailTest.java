package Test;
import static org.junit.jupiter.api.Assertions.*;

import java.time.DayOfWeek;
import java.time.LocalDate;

import org.junit.jupiter.api.Test;

import model.WorkDetail;

class WorkDetailTest {

    @Test
    public void testConstructor_WeekdayWithValidWorkShifts() {
        LocalDate workDate = LocalDate.now().with(DayOfWeek.MONDAY);
        String workShifts = "cachieu";
        double lateHours = 0.5;
        double earlyLeaveHours = 0.0;
        String monday = "Present";
        String tuesday = "Absent";
        String wednesday = "Present";
        String thursday = "Present";
        String friday = "Present";
        String saturday = "Off";

        WorkDetail workDetail = new WorkDetail(workDate, workShifts, lateHours, earlyLeaveHours, monday, tuesday, wednesday, thursday, friday, saturday);

        assertTrue(workShifts.equals("casang") || workShifts.equals("cachieu"));
    }

    @Test
    public void testConstructor_InvalidWorkDate() {
        LocalDate workDate = null;
        String workShifts = "cachieu";
        double lateHours = 0.5;
        double earlyLeaveHours = 0.0;
        String monday = "Present";
        String tuesday = "Absent";
        String wednesday = "Present";
        String thursday = "Present";
        String friday = "Present";
        String saturday = "Off";

        assertThrows(IllegalArgumentException.class,
                () -> new WorkDetail(workDate, workShifts, lateHours, earlyLeaveHours, monday, tuesday, wednesday, thursday, friday, saturday),
                "Work date cannot be null.");
    }

    @Test
    public void testConstructor_InvalidWorkShifts() {
        LocalDate workDate = LocalDate.now();
        String workShifts = "invalidShift";
        double lateHours = 0.5;
        double earlyLeaveHours = 0.0;
        String monday = "Present";
        String tuesday = "Absent";
        String wednesday = "Present";
        String thursday = "Present";
        String friday = "Present";
        String saturday = "Off";

        assertThrows(IllegalArgumentException.class,
                () -> new WorkDetail(workDate, workShifts, lateHours, earlyLeaveHours, monday, tuesday, wednesday, thursday, friday, saturday),
                "Invalid work shifts: Work shifts must be either 'casang' or 'cachieu'.");
    }

    @Test
    public void testConstructor_InvalidLateHours() {
        LocalDate workDate = LocalDate.now();
        String workShifts = "cachieu";
        double lateHours = -1.0;
        double earlyLeaveHours = 0.0;
        String monday = "Present";
        String tuesday = "Absent";
        String wednesday = "Present";
        String thursday = "Present";
        String friday = "Present";
        String saturday = "Off";

        assertThrows(IllegalArgumentException.class,
                () -> new WorkDetail(workDate, workShifts, lateHours, earlyLeaveHours, monday, tuesday, wednesday, thursday, friday, saturday),
                "Invalid late hours: Late hours cannot be negative.");
    }

    @Test
    public void testConstructor_InvalidEarlyLeaveHours() {
        LocalDate workDate = LocalDate.now();
        String workShifts = "cachieu";
        double lateHours = 0.5;
        double earlyLeaveHours = -1.0;
        String monday = "Present";
        String tuesday = "Absent";
        String wednesday = "Present";
        String thursday = "Present";
        String friday = "Present";
        String saturday = "Off";

        assertThrows(IllegalArgumentException.class,
                () -> new WorkDetail(workDate, workShifts, lateHours, earlyLeaveHours, monday, tuesday, wednesday, thursday, friday, saturday),
                "Invalid early leave hours: Early leave hours cannot be negative.");
    }

    @Test
    public void testConstructor_WeekendWithRestShift() {
        LocalDate workDate = LocalDate.now().with(DayOfWeek.SATURDAY);
        String workShifts = "cachieu";
        double lateHours = 0.0;
        double earlyLeaveHours = 0.0;
        String monday = "Present";
        String tuesday = "Absent";
        String wednesday = "Present";
        String thursday = "Present";
        String friday = "Present";
        String saturday = "Off";

        WorkDetail workDetail = new WorkDetail(workDate, workShifts, lateHours, earlyLeaveHours, monday, tuesday, wednesday, thursday, friday, saturday);

        assertEquals(workShifts, "cachieu");
    }

    @Test
    public void testConstructor_ValidPositiveLateHours() {
        LocalDate workDate = LocalDate.now();
        String workShifts = "cachieu";
        double lateHours = 1.2;
        double earlyLeaveHours = 0.0;
        String monday = "Present";
        String tuesday = "Absent";
        String wednesday = "Present";
        String thursday = "Present";
        String friday = "Present";
        String saturday = "Off";

        WorkDetail workDetail = new WorkDetail(workDate, workShifts, lateHours, earlyLeaveHours, monday, tuesday, wednesday, thursday, friday, saturday);

        assertEquals(lateHours, workDetail.getLateHours(), 0.001);
    }

    @Test
    public void testConstructor_InvalidLateHoursExceedingLimit() {
        LocalDate workDate = LocalDate.now();
        String workShifts = "cachieu";
        double lateHours = 6.0;
        double earlyLeaveHours = 0.0;
        String monday = "Present";
        String tuesday = "Absent";
        String wednesday = "Present";
        String thursday = "Present";
        String friday = "Present";
        String saturday = "Off";

        assertThrows(IllegalArgumentException.class,
                () -> new WorkDetail(workDate, workShifts, lateHours, earlyLeaveHours, monday, tuesday, wednesday, thursday, friday, saturday));
    }
}
