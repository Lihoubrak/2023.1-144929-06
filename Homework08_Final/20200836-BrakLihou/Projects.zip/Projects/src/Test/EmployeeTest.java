package Test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import javafx.embed.swing.JFXPanel;
import javafx.scene.control.Button;
import model.Employee;
import model.WorkDetail;

class EmployeeTest {
    @BeforeAll
    public static void initJFX() {
        // Initialize JavaFX toolkit
        JFXPanel jfxPanel = new JFXPanel();
    }
	@Test
	public void testEmployeeConstructor() {
	  // Create test data
	  int employeeID = 123;
	  String name = "John Doe";
	  String department = "IT";
	  String position = "Software Engineer";
	  Button button = new Button("ADD");
	  List<WorkDetail> workDetails = List.of(
              new WorkDetail(LocalDate.of(2022, 1, 5), "casang", 1, 3, "4", "2", "5", "4", "4", "5")
      );
	  
	  // Create Employee object
	  Employee employee = new Employee(employeeID, name, department, position, button, workDetails);
	  
	  // Assert values
	  assertEquals(employeeID, employee.getEmployeeID());
	  assertEquals(name, employee.getName());
	  assertEquals(department, employee.getDepartment());
	  assertEquals(position, employee.getPosition());
	  assertEquals(button, employee.getButton());
	  assertEquals(workDetails, employee.getWorkDetails());
	}
	@Test
	public void testGettersAndSetters() {
	  // Create Employee object
	  Employee employee = new Employee(123, "Jane Doe", "Marketing", "Marketing Manager", null, null);
	  
	  // Test setters
	  employee.setEmployeeID(456);
	  employee.setName("Jane Smith");
	  employee.setDepartment("Sales");
	  employee.setPosition("Sales Manager");
	  
	  // Test getters
	  assertEquals(456, employee.getEmployeeID());
	  assertEquals("Jane Smith", employee.getName());
	  assertEquals("Sales", employee.getDepartment());
	  assertEquals("Sales Manager", employee.getPosition());
	}
}
