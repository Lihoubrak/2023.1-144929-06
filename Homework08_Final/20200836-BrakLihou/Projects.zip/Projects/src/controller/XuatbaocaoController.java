package controller;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class XuatbaocaoController {

    @FXML
    private Button btn_csv;

    @FXML
    private Button btn_excel;

    @FXML
	public Button btn_back;

    @FXML
	public void handleClickBack() {
    	  try {
              // Load Nhanvien.fxml
              FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/quanlychamcong.fxml"));
              Parent root = loader.load();
              Scene scene = new Scene(root);

              // Get the current Stage
              Stage stage = (Stage) btn_back.getScene().getWindow();

              // Set the new Scene into the Stage
              stage.setScene(scene);

              // Show the Stage
              stage.show();
          } catch (Exception e) {
              e.printStackTrace();
          }
    }
    @FXML
    void handleClickCSV(ActionEvent event) {
        try {
            // Load Nhanvien.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/nhanvien.fxml"));
            Parent root = loader.load();

//            // Access the controller of Nhanvien.fxml
            NhanvienController nhanvienController = loader.getController();

            // Pass the button information to the receiving controller
            nhanvienController.receiveButtonInformation("ADD");
            nhanvienController.setCheckScene(true);
            

            // Use the received information within NhanvienController
            nhanvienController.useReceivedButtonText();
            // Create a new Scene
            Scene scene = new Scene(root);

            // Get the current Stage
            Stage stage = (Stage) btn_csv.getScene().getWindow();

            // Set the new Scene into the Stage
            stage.setScene(scene);

            // Show the Stage
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    @FXML
    void handleClickExcel(ActionEvent event) {
    	  try {
              // Load Nhanvien.fxml
              FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/nhanvien.fxml"));
              Parent root = loader.load();

              // Access the controller of Nhanvien.fxml
              NhanvienController nhanvienController = loader.getController();

              // Pass the button information to the receiving controller
              nhanvienController.receiveButtonInformation("ADD");
              nhanvienController.setCheckScene(true);

              // Use the received information within NhanvienController
              nhanvienController.useReceivedButtonText();

              // Create a new Scene
              Scene scene = new Scene(root);

              // Get the current Stage
              Stage stage = (Stage) btn_csv.getScene().getWindow();

              // Set the new Scene into the Stage
              stage.setScene(scene);

              // Show the Stage
              stage.show();
          } catch (Exception e) {
              e.printStackTrace();
          }
    }    
}
