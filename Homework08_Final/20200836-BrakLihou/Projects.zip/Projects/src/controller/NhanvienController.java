package controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.Employee;
import model.Officer;
import model.WorkDetail;
import model.Worker;

public class NhanvienController {

    @FXML
    private TableView<Employee> workerTableView;

    @FXML
    private TableColumn<Employee, String> workerNameColumn;

    @FXML
    private TableColumn<Employee, String> workerDepartmentColumn;

    @FXML
    private TableColumn<Employee, String> workerPositionColumn;

    @FXML
    private TableColumn<Employee, Button> workerDeleteColumn;

    @FXML
    private TableView<Employee> officerTableView;

    @FXML
    private TableColumn<Employee, String> officerNameColumn;

    @FXML
    private TableColumn<Employee, String> officerDepartmentColumn;

    @FXML
    private TableColumn<Employee, String> officerPositionColumn;

    @FXML
    private TableColumn<Employee, Button> officerDeleteColumn;

    @FXML
    private Button btn_back,exportButton;
    @FXML 
    private AnchorPane anchorpane;
    private String receivedButtonText;
    private ObservableList<Employee> workerData = FXCollections.observableArrayList();
    private ObservableList<Employee> officerData = FXCollections.observableArrayList();
    private Employee selectedEmployee; 
    private boolean checkScene ;
    private String textBtn;
    private String setEdit;
    
    
    
    public String getSetEdit() {
		return setEdit;
	}
	public void setSetEdit(String setEdit) {
		this.setEdit = setEdit;
	}
	public String getTextBtn() {
		return textBtn;
	}
	public void setTextBtn(String textBtn) {
		this.textBtn = textBtn;
	}
	public boolean isCheckScene() {
		return checkScene;
	}
	public void setCheckScene(boolean checkScene) {
		if (checkScene) {
		    createAndAddButtons("0 ADD");
		}
	}
	public Button Btn(String text) {
    	Button button = new Button(text);
    	return button;
    }
    private void createAndAddButtons(String buttonText) {
        // Create and add "10 Add" button
        Button addButton = new Button(buttonText);
        addButton.setLayoutX(146.0);
        addButton.setLayoutY(14.0);
        addButton.setStyle("-fx-background-color: #e67e22; -fx-text-fill: white; -fx-cursor: hand;");
        anchorpane.getChildren().add(addButton);

        // Create and add "Export" button
        Button exportButton = new Button("Export");
        exportButton.setLayoutX(217.0);
        exportButton.setLayoutY(14.0);
        exportButton.setOnAction(event -> handleExportButtonClick());
        exportButton.setStyle("-fx-background-color: #2c3e50; -fx-text-fill: white; -fx-cursor: hand;");
        exportButton.setId("exportButton"); // Set the ID here
        anchorpane.getChildren().add(exportButton);

    }
    @FXML
    private void handleExportButtonClick() {
    	 System.out.println("10 Add button Eprot!");
    }

    @FXML
    private void initialize() {
    	 setupWorkerTableView();
         setupOfficerTableView();
         initializeData();
         
    }

    private void setupWorkerTableView() {
        workerTableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        workerTableView.setItems(workerData);
        workerNameColumn.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("name"));
        workerDepartmentColumn.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("department"));
        workerPositionColumn.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("position"));
        workerDeleteColumn.setCellValueFactory(param -> {
            Button button = createButton();
            button.setOnAction(event -> {
                deleteEmployee(workerTableView.getSelectionModel().getSelectedItem());
            });

            return new SimpleObjectProperty<>(button);
        });


        workerTableView.setOnMouseClicked(this::handleRowClick);
    }

    private void setupOfficerTableView() {
        officerTableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        officerTableView.setItems(officerData);
        officerNameColumn.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("name"));
        officerDepartmentColumn.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("department"));
        officerPositionColumn.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("position"));
        officerDeleteColumn.setCellValueFactory(param -> {
            Button button = createButton();
            button.setOnAction(event -> {
                deleteEmployee(officerTableView.getSelectionModel().getSelectedItem());
            });

            return new SimpleObjectProperty<>(button);
        });

        officerTableView.setOnMouseClicked(this::handleRowClick);
    }

    private Button createButton() {
        return new Button(useReceivedButtonText());
    }
    public void receiveButtonInformation(String buttonText) {
        receivedButtonText = buttonText;
    }

    public String useReceivedButtonText() {
        return receivedButtonText;
    }

    @FXML
    private void initializeData() {
        List<WorkDetail> workerWorkDetails = createWorkerWorkDetails();
        List<WorkDetail> officerWorkDetails = createOfficerWorkDetails();
        
        workerData.add(new Worker(1, "John Doe", "HR", "Manager",  createButton(), workerWorkDetails));
        officerData.add(new Officer(2, "Jane Smith", "Finance", "Officer",  createButton(), officerWorkDetails));
    }


    private List<WorkDetail> createWorkerWorkDetails() {
        return List.of(
                new WorkDetail(LocalDate.of(2022, 1, 5), "casang", 1, 3, "4", "2", "5", "4", "4", "5")
        );
    }

    private List<WorkDetail> createOfficerWorkDetails() {
        return List.of(
                new WorkDetail(LocalDate.now(), "casang", 1, 1, "co", "khong", "co", "khong", "khong", "co")
        );
    }

    @FXML
    private void handleBackHome() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/quanlychamcong.fxml"));
            Parent root = loader.load();
            Stage currentStage = (Stage) btn_back.getScene().getWindow();
            Scene scene = new Scene(root);
            currentStage.setScene(scene);
            currentStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleRowClick(MouseEvent event) {
    	if(getSetEdit()=="Edit"){
    		 try {
    	            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/thongtinnhanvien.fxml"));
    	            Parent root = loader.load();

    	          
    	            Stage currentStage = (Stage) workerTableView.getScene().getWindow();
    	            currentStage.setScene(new Scene(root));
    	        } catch (IOException e) {
    	            e.printStackTrace();
    	        }
    	}else {
    		 if (event.getClickCount() == 1) {
    	            selectedEmployee = getSelectedEmployee(event);

    	            if (selectedEmployee != null) {
    	                navigateToChitietNhanvien(selectedEmployee.getWorkDetails());
    	            }
    	        }
    	}
       
    }

    private Employee getSelectedEmployee(MouseEvent event) {
        if (event.getSource() == workerTableView) {
            return workerTableView.getSelectionModel().getSelectedItem();
        } else if (event.getSource() == officerTableView) {
            return officerTableView.getSelectionModel().getSelectedItem();
        }
        return null;
    }

    private void navigateToChitietNhanvien(List<WorkDetail> workDetails) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/chitiet_nhanvien.fxml"));
            Parent root = loader.load();

            ChiTietController chitietController = loader.getController();
            chitietController.setEmployeeData(workDetails);

            Stage currentStage = (Stage) workerTableView.getScene().getWindow();
            currentStage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void deleteEmployee(Employee employee) {
        if (employee instanceof Worker) {
            removeEmployeeFromList(workerData, employee);
        } else if (employee instanceof Officer) {
            removeEmployeeFromList(officerData, employee);
        }

        System.out.println("Employee deleted!");
    }

    private void removeEmployeeFromList(ObservableList<Employee> dataList, Employee employee) {
        dataList.removeIf(e -> e.getEmployeeID() == employee.getEmployeeID());
    }
	

}
