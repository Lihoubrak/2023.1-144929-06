package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class ThongtinController {

    @FXML
    private BorderPane mainBorderPane;
    @FXML
    private Button editButton,btn_back;
    @FXML
    private TextField editNameField;
    @FXML
    private TextField editDobField;
    @FXML
    private TextField editDepartmentField;
    @FXML
    private TextField editLateHoursField;
    @FXML
    private TextField editEarlyHoursField;
    @FXML
    private TextField editTotalWorkField;
    
    // Flag to track whether in edit mode or not
    private boolean editMode = false;
    @FXML
    private void handleEditButtonAction(ActionEvent event) {
        // Toggle the edit mode
        editMode = !editMode;

        // Enable or disable text fields based on edit mode
        setEditableTextFields(editMode);

        // Change the text of the edit button based on edit mode
        editButton.setText(editMode ? "Save" : "Edit");
    }

    private void setEditableTextFields(boolean editable) {
        editNameField.setEditable(editable);
        editDobField.setEditable(editable);
        editDepartmentField.setEditable(editable);
        editLateHoursField.setEditable(editable);
        editEarlyHoursField.setEditable(editable);
        editTotalWorkField.setEditable(editable);
    }
    @FXML
    private void handleback() {
    	  try {
              // Load Nhanvien.fxml
              FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/quanlychamcong.fxml"));
              Parent root = loader.load();
              Scene scene = new Scene(root);

              // Get the current Stage
              Stage stage = (Stage) btn_back.getScene().getWindow();

              // Set the new Scene into the Stage
              stage.setScene(scene);

              // Show the Stage
              stage.show();
          } catch (Exception e) {
              e.printStackTrace();
          }
    }
}
