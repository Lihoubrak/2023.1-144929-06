package controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.WorkDetail;

public class ChiTietController {

    private static final String NHANVIEN_FXML_PATH = "/view/nhanvien.fxml";
    private static final String LOGO_IMAGE_PATH = "/images/logo.png";

    @FXML
    private TableView<WorkDetail> tableView;

    @FXML
    private TableColumn<WorkDetail, Integer> Friday;

    @FXML
    private TableColumn<WorkDetail, Integer> Monday;

    @FXML
    private TableColumn<WorkDetail, Integer> Saturday;

    @FXML
    private TableColumn<WorkDetail, Integer> Thursday;

    @FXML
    private TableColumn<WorkDetail, Integer> Tuesday;

    @FXML
    private TableColumn<WorkDetail, Integer> Wednesday;

    @FXML
    private TableColumn<WorkDetail, Integer> earlyLeaveColumn;

    @FXML
    private TableColumn<WorkDetail, Integer> lateHoursColumn;

    @FXML
    private TableColumn<WorkDetail, Integer> workDateColumn;

    @FXML
    private TableColumn<WorkDetail, Integer> workShiftsColumn;

    @FXML
    private Label username;

    @FXML
    private Button btn_back;

    @FXML
    private TabPane tabPane;

    @FXML
    private Tab three_monthTab;

    @FXML
    private Tab one_monthTab;

    @FXML
    private Tab one_yearTab;

    @FXML
    private ImageView logoProfile;

    @FXML
    private Label totalLateLabel, totalEarlyLabel, totalWorkLabel;
    @FXML
    private void initialize() {
    
    }
    public void setEmployeeData(List<WorkDetail> workDetails) {
        ObservableList<WorkDetail> workDetailList = FXCollections.observableArrayList(workDetails);

        Monday.setCellValueFactory(new PropertyValueFactory<>("MONDAY"));
        Tuesday.setCellValueFactory(new PropertyValueFactory<>("TUESDAY"));
        Wednesday.setCellValueFactory(new PropertyValueFactory<>("WEDNESDAY"));
        Thursday.setCellValueFactory(new PropertyValueFactory<>("THURSDAY"));
        Friday.setCellValueFactory(new PropertyValueFactory<>("FRIDAY"));
        Saturday.setCellValueFactory(new PropertyValueFactory<>("SATURDAY"));
        workDateColumn.setCellValueFactory(new PropertyValueFactory<>("workDate"));
        workShiftsColumn.setCellValueFactory(new PropertyValueFactory<>("workShifts"));
        earlyLeaveColumn.setCellValueFactory(new PropertyValueFactory<>("earlyLeaveHours"));
        lateHoursColumn.setCellValueFactory(new PropertyValueFactory<>("lateHours"));

        tableView.setItems(workDetailList);
        updateTotals();
    	
  	  
        
    }

    @FXML
    private void handleBackButtonClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(NHANVIEN_FXML_PATH));
            Parent root = loader.load();

            // Get the current stage
            Stage currentStage = (Stage) btn_back.getScene().getWindow();
//            NhanvienController nhanvienController = loader.getController();
//            nhanvienController.receiveButtonInformation("ADD");
//            nhanvienController.setCheckScene(true);
//            nhanvienController.receiveButtonInformation("DELETE");
//            nhanvienController.setCheckScene(false);
            Scene scene = new Scene(root);
            currentStage.setScene(scene);

            // Show the stage
            currentStage.show();
        } catch (IOException e) {
            e.printStackTrace(); // Handle the exception appropriately
        }
    }




    @FXML
    private void updateTotals() {
        List<WorkDetail> workDetails = tableView.getItems();
        LocalDate threeMonthsAgo = LocalDate.now().minus(3, ChronoUnit.MONTHS).withDayOfMonth(1);
        LocalDate oneMonthAgo = LocalDate.now().minus(1, ChronoUnit.MONTHS).withDayOfMonth(1);
        LocalDate oneYearAgo = LocalDate.now().minus(1, ChronoUnit.YEARS).withDayOfMonth(1);


        double totalLate3Months = calculateTotalLate(getWorkDetailsInDateRange(workDetails, threeMonthsAgo, LocalDate.now()));
        double totalEarly3Months = calculateTotalEarly(getWorkDetailsInDateRange(workDetails, threeMonthsAgo, LocalDate.now()));
        double totalWork3Months = calculateTotalWork(getWorkDetailsInDateRange(workDetails, threeMonthsAgo, LocalDate.now()));

        double totalLate1Month = calculateTotalLate(getWorkDetailsInDateRange(workDetails, oneMonthAgo, LocalDate.now()));
        double totalEarly1Month = calculateTotalEarly(getWorkDetailsInDateRange(workDetails, oneMonthAgo, LocalDate.now()));
        double totalWork1Month = calculateTotalWork(getWorkDetailsInDateRange(workDetails, oneMonthAgo, LocalDate.now()));

        double totalLate1Year = calculateTotalLate(getWorkDetailsInDateRange(workDetails, oneYearAgo, LocalDate.now()));
        double totalEarly1Year = calculateTotalEarly(getWorkDetailsInDateRange(workDetails, oneYearAgo, LocalDate.now()));
        double totalWork1Year = calculateTotalWork(getWorkDetailsInDateRange(workDetails, oneYearAgo, LocalDate.now()));

        updateTabContent(three_monthTab, totalLate3Months, totalEarly3Months, totalWork3Months);
        updateTabContent(one_monthTab, totalLate1Month, totalEarly1Month, totalWork1Month);
        updateTabContent(one_yearTab, totalLate1Year, totalEarly1Year, totalWork1Year);
       
    }

    private List<WorkDetail> getWorkDetailsInDateRange(List<WorkDetail> workDetails, LocalDate startDate, LocalDate endDate) {
        return workDetails.stream()
                .filter(workDetail -> !workDetail.getWorkDate().isBefore(startDate) && !workDetail.getWorkDate().isAfter(endDate))
                .collect(Collectors.toList());
    }

    private double calculateTotalLate(List<WorkDetail> workDetails) {
        return workDetails.stream().mapToDouble(WorkDetail::getLateHours).sum();
    }

    private double calculateTotalEarly(List<WorkDetail> workDetails) {
        return workDetails.stream().mapToDouble(WorkDetail::getEarlyLeaveHours).sum();
    }

    private double calculateTotalWork(List<WorkDetail> workDetails) {
        return workDetails.stream()
                .mapToDouble(workDetail -> {
                    double total = 0.0;

                    // Check each day and convert to numeric value
                    if (!workDetail.getMONDAY().equalsIgnoreCase("co") && !workDetail.getMONDAY().equalsIgnoreCase("khong")) {
                        total += Double.parseDouble(workDetail.getMONDAY());
                    }

                    if (!workDetail.getTUESDAY().equalsIgnoreCase("co") && !workDetail.getTUESDAY().equalsIgnoreCase("khong")) {
                        total += Double.parseDouble(workDetail.getTUESDAY());
                    }

                    if (!workDetail.getWEDNESDAY().equalsIgnoreCase("co") && !workDetail.getWEDNESDAY().equalsIgnoreCase("khong")) {
                        total += Double.parseDouble(workDetail.getWEDNESDAY());
                    }

                    if (!workDetail.getTHURSDAY().equalsIgnoreCase("co") && !workDetail.getTHURSDAY().equalsIgnoreCase("khong")) {
                        total += Double.parseDouble(workDetail.getTHURSDAY());
                    }

                    if (!workDetail.getFRIDAY().equalsIgnoreCase("co") && !workDetail.getFRIDAY().equalsIgnoreCase("khong")) {
                        total += Double.parseDouble(workDetail.getFRIDAY());
                    }

                    if (!workDetail.getSATURDAY().equalsIgnoreCase("co") && !workDetail.getSATURDAY().equalsIgnoreCase("khong")) {
                        total += Double.parseDouble(workDetail.getSATURDAY());
                    }

                    return total;
                })
                .sum();
    }

    private void updateTabContent(Tab tab, double totalLate, double totalEarly, double totalWork) {
        AnchorPane contentPane = (AnchorPane) tab.getContent();
        Label totalLateLabel = (Label) contentPane.lookup("#totalLateLabel");
        Label totalEarlyLabel = (Label) contentPane.lookup("#totalEarlyLabel");
        Label totalWorkLabel = (Label) contentPane.lookup("#totalWorkLabel");

        totalLateLabel.setText(String.valueOf(totalLate));
        totalEarlyLabel.setText(String.valueOf(totalEarly));
        totalWorkLabel.setText(String.valueOf(totalWork));
    }

    @FXML
    private void initializeLogo() {
        Image logoImage = new Image(getClass().getResourceAsStream(LOGO_IMAGE_PATH));
        logoProfile.setImage(logoImage);
    }
}
