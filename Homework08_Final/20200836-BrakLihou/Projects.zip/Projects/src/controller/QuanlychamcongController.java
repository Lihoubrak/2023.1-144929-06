package controller;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class QuanlychamcongController {
    @FXML
    private Button btn_xemBaocao;

    @FXML
    private Button btn_xuatbaocao;

    @FXML
    private Button btn_suathongtin;

    @FXML
    private ImageView logoImageView;

    // Image paths
    private String logoImagePath = "/images/image1.png";
    private String xemBaocaoImagePath = "/images/image4.png";
    private String xuatBaocaoImagePath = "/images/image3.png";
    private String suaThongTinImagePath = "/images/image2.png";

    // Add initialization logic here
    @FXML
    private void initialize() {
        // Load the image for the logo
        Image logoImage = new Image(getClass().getResourceAsStream(logoImagePath));
        logoImageView.setImage(logoImage);

        // Add images and text to buttons
        setImageAndTextForButton(btn_xemBaocao, xemBaocaoImagePath, "Xem bao cao cham cong");
        setImageAndTextForButton(btn_xuatbaocao, xuatBaocaoImagePath, "Xuat bao cao cham cong");
        setImageAndTextForButton(btn_suathongtin, suaThongTinImagePath, "Sua doi thong tin nhan vien");
    }

    // Utility method to set image and text for a button
    private void setImageAndTextForButton(Button button, String imagePath, String buttonText) {
        Image buttonImage = new Image(getClass().getResourceAsStream(imagePath));
        ImageView imageView = new ImageView(buttonImage);
        imageView.setFitWidth(50); // Adjust the width as needed
        imageView.setFitHeight(50); // Adjust the height as needed
        button.setGraphic(imageView);
        button.setText(buttonText);
    }
	@FXML
	private void handleXuatBaocao() {
		try {
            // Load the new FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/xuatbaocao.fxml"));
            Parent root = loader.load();

            // Get the current stage
            Stage currentStage = (Stage) btn_xuatbaocao.getScene().getWindow();

            // Set the scene with the loaded FXML file
            Scene scene = new Scene(root);
            currentStage.setScene(scene);

            // Show the updated stage
            currentStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
    // Add event handling methods here
    @FXML
    private void handleXemBaoCaoButton() {
    	try {
            // Load Nhanvien.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/nhanvien.fxml"));
            Parent root = loader.load();

            // Access the controller of Nhanvien.fxml
            NhanvienController nhanvienController = loader.getController();

            // Pass the button information to the receiving controller
            nhanvienController.receiveButtonInformation("DELETE");

            // Use the received information within NhanvienController
            nhanvienController.useReceivedButtonText();

            // Create a new Scene
            Scene scene = new Scene(root);

            // Get the current Stage
            Stage stage = (Stage) btn_xemBaocao.getScene().getWindow();

            // Set the new Scene into the Stage
            stage.setScene(scene);

            // Show the Stage
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @FXML
	private void handleSuaDoi() {
    	try {
            // Load Nhanvien.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/nhanvien.fxml"));
            Parent root = loader.load();

            Scene scene = new Scene(root);
            NhanvienController nhanvienController = loader.getController();

            // Pass the button information to the receiving controller
            nhanvienController.setSetEdit("Edit");
            // Get the current Stage
            Stage stage = (Stage) btn_suathongtin.getScene().getWindow();

            // Set the new Scene into the Stage
            stage.setScene(scene);

            // Show the Stage
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
	    }
}
