package model;
import java.time.LocalDate;

public class WorkDetail {
    private LocalDate workDate;
    private String workShifts;
    private double lateHours;
    private double earlyLeaveHours;
    private String MONDAY;
    private String TUESDAY;
    private String WEDNESDAY;
    private String THURSDAY;
    private String FRIDAY;
    private String SATURDAY;

    public WorkDetail(LocalDate workDate, String workShifts, double lateHours, double earlyLeaveHours,
                      String MONDAY, String TUESDAY, String WEDNESDAY, String THURSDAY, String FRIDAY, String SATURDAY) {
        validateWorkDate(workDate);
        validateLateHours(lateHours);
        validateEarlyLeaveHours(earlyLeaveHours);
        validateWorkShifts(workShifts);

        this.workDate = workDate;
        this.workShifts = workShifts;
        this.lateHours = lateHours;
        this.earlyLeaveHours = earlyLeaveHours;
        this.MONDAY = MONDAY;
        this.TUESDAY = TUESDAY;
        this.WEDNESDAY = WEDNESDAY;
        this.THURSDAY = THURSDAY;
        this.FRIDAY = FRIDAY;
        this.SATURDAY = SATURDAY;
    }

    public LocalDate getWorkDate() {
        return workDate;
    }

    public String getWorkShifts() {
        return workShifts;
    }

    public double getLateHours() {
        return lateHours;
    }

    public double getEarlyLeaveHours() {
        return earlyLeaveHours;
    }

    public String getMONDAY() {
        return MONDAY;
    }

    public String getTUESDAY() {
        return TUESDAY;
    }

    public String getWEDNESDAY() {
        return WEDNESDAY;
    }

    public String getTHURSDAY() {
        return THURSDAY;
    }

    public String getFRIDAY() {
        return FRIDAY;
    }

    public String getSATURDAY() {
        return SATURDAY;
    }

    public void setWorkDate(LocalDate workDate) {
        validateWorkDate(workDate);
        this.workDate = workDate;
    }

    public void setWorkShifts(String workShifts) {
        validateWorkShifts(workShifts);
        this.workShifts = workShifts;
    }

    public void setLateHours(double lateHours) {
        validateLateHours(lateHours);
        this.lateHours = lateHours;
    }

    public void setEarlyLeaveHours(double earlyLeaveHours) {
        validateEarlyLeaveHours(earlyLeaveHours);
        this.earlyLeaveHours = earlyLeaveHours;
    }

    public void setMONDAY(String MONDAY) {
        this.MONDAY = MONDAY;
    }

    public void setTUESDAY(String TUESDAY) {
        this.TUESDAY = TUESDAY;
    }

    public void setWEDNESDAY(String WEDNESDAY) {
        this.WEDNESDAY = WEDNESDAY;
    }

    public void setTHURSDAY(String THURSDAY) {
        this.THURSDAY = THURSDAY;
    }

    public void setFRIDAY(String FRIDAY) {
        this.FRIDAY = FRIDAY;
    }

    public void setSATURDAY(String SATURDAY) {
        this.SATURDAY = SATURDAY;
    }

    private void validateWorkDate(LocalDate workDate) {
        if (workDate == null) {
            throw new IllegalArgumentException("Work date cannot be null.");
        }
    }

    private void validateLateHours(double lateHours) {
        if (lateHours < 0) {
            throw new IllegalArgumentException("Late hours cannot be negative.");
        }
        if (lateHours > 4.0) {
            throw new IllegalArgumentException("Invalid late hours: Late hours cannot exceed 4.0 hours.");
        } 
    }

    private void validateEarlyLeaveHours(double earlyLeaveHours) {
        if (earlyLeaveHours < 0) {
            throw new IllegalArgumentException("Early leave hours cannot be negative.");
        }
    }

    private void validateWorkShifts(String workShifts) {
        if (workShifts == null || (!workShifts.trim().equals("casang") && !workShifts.trim().equals("cachieu"))) {
            throw new IllegalArgumentException("Invalid work shifts. Shifts must be either 'casang' or 'cachieu'.");
        }
        
    }
    
}
