package model;

import java.time.LocalDate;

public class WorkDay {

    private LocalDate date;
    private int ca1;
    private int ca2;
    private int c3;
    private int workingHours;
    private int overtimeHours;

    // Constructors, getters, and setters

    public WorkDay(LocalDate date, int ca1, int ca2, int c3, int workingHours, int overtimeHours) {
        this.date = date;
        this.ca1 = ca1;
        this.ca2 = ca2;
        this.c3 = c3;
        this.workingHours = workingHours;
        this.overtimeHours = overtimeHours;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public int getCa1() {
        return ca1;
    }

    public void setCa1(int ca1) {
        this.ca1 = ca1;
    }

    public int getCa2() {
        return ca2;
    }

    public void setCa2(int ca2) {
        this.ca2 = ca2;
    }

    public int getC3() {
        return c3;
    }

    public void setC3(int c3) {
        this.c3 = c3;
    }

    public int getWorkingHours() {
        return workingHours;
    }

    public void setWorkingHours(int workingHours) {
        this.workingHours = workingHours;
    }

    public int getOvertimeHours() {
        return overtimeHours;
    }

    public void setOvertimeHours(int overtimeHours) {
        this.overtimeHours = overtimeHours;
    }
}
