package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

import java.time.LocalDate;
import java.util.Date;

import javafx.scene.control.cell.PropertyValueFactory;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.util.Callback;
import model.WorkDay;

public class WorkDayController {

    @FXML
    private TableView<WorkDay> tableView;

    @FXML
    private TableColumn<WorkDay, Date> ngay;

    @FXML
    private TableColumn<WorkDay, Integer> ca1;

    @FXML
    private TableColumn<WorkDay, Integer> ca2;

    @FXML
    private TableColumn<WorkDay, Integer> c3;

    @FXML
    private TableColumn<WorkDay, Integer> lamviec;

    @FXML
    private TableColumn<WorkDay, Integer> tangca;

    @FXML
    private Text nguyenVanAA;

    @FXML
    private TextField searchTextField;

    // Add any additional methods or event handlers as needed

    @FXML
    private void initialize() {
       
        initializeTableView();
    }

    // Method to initialize the TableView with sample data
    private void initializeTableView() {
        ngay.setCellValueFactory(new PropertyValueFactory<>("date"));
        ca1.setCellValueFactory(new PropertyValueFactory<>("ca1"));
        ca2.setCellValueFactory(new PropertyValueFactory<>("ca2"));
        c3.setCellValueFactory(new PropertyValueFactory<>("c3"));
        lamviec.setCellValueFactory(new PropertyValueFactory<>("workingHours"));
        tangca.setCellValueFactory(new PropertyValueFactory<>("overtimeHours"));

        // Assuming you have a method to get sample data
        tableView.setItems(getSampleData());
    }

    // Method to get sample data 
    private ObservableList<WorkDay> getSampleData() {
        //implement this method to return a list of WorkDay objects
        
        ObservableList<WorkDay> data = FXCollections.observableArrayList();
        data.add(new WorkDay(LocalDate.parse("2023-02-01"), 4, 4, 3, 9, 3));
        data.add(new WorkDay(LocalDate.parse("2023-02-02"), 3, 3, 2, 6, 6));
        data.add(new WorkDay(LocalDate.parse("2023-02-03"), 1, 3, 2, 4, 2));
        data.add(new WorkDay(LocalDate.parse("2023-02-04"), 3, 2, 1, 5, 1));
        data.add(new WorkDay(LocalDate.parse("2023-02-05"), 3, 3, 2, 6, 6));
        data.add(new WorkDay(LocalDate.parse("2023-02-06"), 3, 3, 2, 6, 6));
        data.add(new WorkDay(LocalDate.parse("2023-02-10"), 3, 3, 2, 6, 6));
        data.add(new WorkDay(LocalDate.parse("2023-02-15"), 1, 2, 2, 3, 2));
        data.add(new WorkDay(LocalDate.parse("2023-02-23"), 2, 2, 3, 4, 3));
        data.add(new WorkDay(LocalDate.parse("2023-02-23"), 1, 0, 1, 1, 1));
        data.add(new WorkDay(LocalDate.parse("2023-02-23"), 2, 2, 0, 4, 0));
                return data;
    }
}
