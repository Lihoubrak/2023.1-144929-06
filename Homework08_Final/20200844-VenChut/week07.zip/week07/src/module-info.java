module week07 {
    requires javafx.controls;
    requires javafx.fxml;

    opens main to javafx.graphics, javafx.fxml;

    // Add the following line to export the controller package
    opens controller;
    opens model;
    opens view;
}
