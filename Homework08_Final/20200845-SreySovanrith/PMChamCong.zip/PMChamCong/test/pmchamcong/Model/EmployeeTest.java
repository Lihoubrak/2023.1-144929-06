
package pmchamcong.Model;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Srey Sovanrith
 */
public class EmployeeTest {
    
    private Employee employee;
    @Before
     public void setUp() {
        // Khởi tạo đối tượng Employee với thông tin mẫu
        employee = new Employee("John Doe", "001", "Male", 30, "123456789", "001");
    }
     
    @Test
    public void testGetName() {
        // Kiểm tra giá trị tên được lấy ra có đúng như khi khởi tạo không
        assertEquals("John Doe", employee.getName());
    }
    @Test
    public void testSetName() {
        // Đặt giá trị mới cho tên và kiểm tra
        employee.setName("Jane Doe");
        assertEquals("Jane Doe", employee.getName());
    }

    @Test
    public void testGetId() {
        assertEquals("001", employee.getId());
    }

    @Test
    public void testSetId() {
        employee.setId("002");
        assertEquals("002", employee.getId());
    }

    @Test
    public void testGetAge() {
        assertEquals(30, employee.getAge());
    }

    @Test
    public void testSetAge() {
        employee.setAge(35);
        assertEquals(35, employee.getAge());
    }
    @Test
    public void testGetGender() {
        assertEquals("Male", employee.getGender());
    }

    @Test
    public void testSetGender() {
        employee.setGender("Male");
        assertEquals("Male", employee.getGender());
    }
    @Test
    public void testGetPhone() {
        assertEquals("123456789", employee.getPhone());
    }

    @Test
    public void testSetPhone() {
        employee.setPhone("123456789");
        assertEquals("123456789", employee.getPhone());
    }
    @Test
    public void testGetTeam() {
        assertEquals("001", employee.getTeam());
    }

    @Test
    public void testSetTeam() {
        employee.setTeam("001");
        assertEquals("001", employee.getTeam());
    }
}
