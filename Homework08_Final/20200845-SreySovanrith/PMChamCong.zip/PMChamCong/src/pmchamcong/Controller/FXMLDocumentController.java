
package pmchamcong.Controller;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import pmchamcong.Database.database;

/**
 *
 * @author ASUS
 */
public class FXMLDocumentController implements Initializable {
    
    
    @FXML
    private Button closebtn;

    @FXML
    private Button loginbtn;

    @FXML
    private PasswordField password;

    @FXML
    private TextField username;
    
    // Database
    private PreparedStatement prepare;
    private Connection connect;
    private ResultSet result;
    
    // handle close btn
    public void close(){
        System.exit(1);
    }
    
    // handle truong don vi nha may login 
    public void adminLogin(){
        String sql = "SELECT * FROM admin WHERE username = ? AND password = ?";
        connect = database.connectDb();
        
        try {
            prepare = connect.prepareStatement(sql);
            prepare.setString(1, username.getText());
            prepare.setString(2, password.getText());
            
            result = prepare.executeQuery();
            Alert alert;
            
            if (username.getText().isEmpty() || password.getText().isEmpty()) {
               alert = new Alert(Alert.AlertType.ERROR);
               alert.setTitle("Error Message");
               alert.setHeaderText(null);
               alert.setContentText("Please fill all blank fields");
               alert.showAndWait();   
            } else {
                if (result.next()) {
                    // Take username of user
//                    getData.username = username.getText();
                    alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Information Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Login Successfully");
                    alert.showAndWait();   
                    
                    loginbtn.getScene().getWindow().hide();
                    // after login will naviagate to homePage
                    Parent root = FXMLLoader.load(getClass().getResource("/pmchamcong/View/HomePage.fxml"));
                    Stage stage = new Stage();
                    Scene scene = new Scene(root);
                    
                    stage.setScene(scene);
                    stage.show();
                } else {
                    alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Wrong username/password");
                    alert.showAndWait();   
                }
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
