package pmchamcong.Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 *
 * @author Srey Sovanrith
 */
public class HomePageController {
    @FXML
    private Button CCNV;

    @FXML
    private Button CCTOANBO;

    @FXML
    private Button ExportFile;
    
    @FXML
    private void handleCCNVAction(ActionEvent event) {
        try {
            // load the fxml for ccnv
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/pmchamcong/View/ChamCongNhanVien.fxml"));
            Parent ChamCongNhanVienPage = loader.load();
            
            // create new scence 
            Scene scene = new Scene(ChamCongNhanVienPage, 1000, 600);
            // get stage from event source
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            
            // change the scene on the stage 
            stage.setScene(scene);
            stage.show();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @FXML
    private void handleCCNVToanBoction(ActionEvent event) {
        try {
            // load the fxml for ccnv
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/pmchamcong/View/ChamCongToanBo.fxml"));
            Parent ChamCongToanBoPage = loader.load();
            
            // create new scence 
            Scene scene = new Scene(ChamCongToanBoPage);
            // get stage from event source
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            
            // change the scene on the stage 
            stage.setScene(scene);
            stage.show();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @FXML
    private void handleExportFileaction(ActionEvent event) {
        try {
            // load the fxml for ccnv
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/pmchamcong/View/ExportForm.fxml"));
            Parent ExportFilePage = loader.load();
            
            // create new scence 
            Scene scene = new Scene(ExportFilePage);
            // get stage from event source
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            
            // change the scene on the stage 
            stage.setScene(scene);
            stage.show();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
