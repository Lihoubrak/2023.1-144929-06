
package pmchamcong.Controller;

import java.io.IOException;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import pmchamcong.Model.Team1AttendanceRecord;
import pmchamcong.Model.Team1List;

/**
 *
 * @author ASUS
 */
public class Team1DetailController {
    @FXML
    private TableView<Team1AttendanceRecord> Team1DetailTable;
    @FXML
    private Label IDLabel;

    @FXML
    private Label NameLabel;

    @FXML
    private Label TeamLabel;

    @FXML
    private Button backbtn;

    @FXML
    private TableColumn<Team1AttendanceRecord, String> colDay;

    @FXML
    private TableColumn<Team1AttendanceRecord, Number> colLate;

    @FXML
    private TableColumn<Team1AttendanceRecord, Number> colOver;

    @FXML
    private TableColumn<Team1AttendanceRecord, Number> colShift1;

    @FXML
    private TableColumn<Team1AttendanceRecord, Number> colShift2;

    @FXML
    private TableColumn<Team1AttendanceRecord, Number> colShift3;

    @FXML
    private ComboBox<String> filterField;
    
    private Team1List currentEmployee;
    
    // handle back
     @FXML
    private void handleBackButtonAction(ActionEvent event) {
        try {
            // Load the homepage FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/pmchamcong/View/Team1.fxml"));
            Parent team1Detail = loader.load();

            // Get the stage from the event source
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // Set the scene to the homepage view
            Scene scene = new Scene(team1Detail);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace(); 
        }
    }
    
    // Call this method from the main controller to pass the employee attendance records.
    public void setAttendanceRecords(List<Team1AttendanceRecord> attendanceRecords) {
        Team1DetailTable.setItems(FXCollections.observableArrayList(attendanceRecords));
    }
    
    @FXML
    private void initialize(){
        colDay.setCellValueFactory(new PropertyValueFactory<>("day"));
        colShift1.setCellValueFactory(new PropertyValueFactory<>("shift1Hours"));
        colShift2.setCellValueFactory(new PropertyValueFactory<>("shift2Hours"));
        colShift3.setCellValueFactory(new PropertyValueFactory<>("shift3Hours"));
        colOver.setCellValueFactory(new PropertyValueFactory<>("overtimeHours"));
        colLate.setCellValueFactory(new PropertyValueFactory<>("lateHours"));
        
        filterField.setItems(FXCollections.observableArrayList("Tháng", "Quý", "Năm"));
        filterField.getSelectionModel().selectFirst();
    }
    
    public void setEmployee(Team1List employee) {
        currentEmployee = employee;
        NameLabel.setText(employee.getName());
        TeamLabel.setText(employee.getTeam());
        IDLabel.setText(employee.getId());

    }
    
}
