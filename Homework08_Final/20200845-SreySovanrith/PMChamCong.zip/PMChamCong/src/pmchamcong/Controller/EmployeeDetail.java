
package pmchamcong.Controller;

import java.io.IOException;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import pmchamcong.Model.AttendenceRecord;
import pmchamcong.Model.Employee;

/**
 *
 * @author ASUS
 */
public class EmployeeDetail {
    @FXML
    private Label NameLabel;

    @FXML
    private Label TeamLabel;

    @FXML
    private Label idLabel;
    
    @FXML
    private Button backbtn;
    
    @FXML
    private TableView<AttendenceRecord> AttendenceTable;
    
    @FXML
    private TableColumn<AttendenceRecord, String> colDay;

    @FXML
    private TableColumn<AttendenceRecord, Number> colLate;

    @FXML
    private TableColumn<AttendenceRecord, Number> colOvertime;

    @FXML
    private TableColumn<AttendenceRecord, Number> colShift1;

    @FXML
    private TableColumn<AttendenceRecord, Number> colShift2;

    @FXML
    private TableColumn<AttendenceRecord, Number> colShift3;
    @FXML
    private ComboBox<String> filter;
    
    private Employee currentEmployee;
    
    // handle back
     @FXML
    private void handleBackButtonAction(ActionEvent event) {
        try {
            // Load the homepage FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/pmchamcong/View/ChamCongNhanVien.fxml"));
            Parent chamcongNhanVien = loader.load();

            // Get the stage from the event source
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // Set the scene to the homepage view
            Scene scene = new Scene(chamcongNhanVien);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace(); 
        }
    }
    
    // Call this method from the main controller to pass the employee attendance records.
    public void setAttendanceRecords(List<AttendenceRecord> attendanceRecords) {
        AttendenceTable.setItems(FXCollections.observableArrayList(attendanceRecords));
    }
    
    @FXML
    private void initialize(){
        colDay.setCellValueFactory(new PropertyValueFactory<>("day"));
        colShift1.setCellValueFactory(new PropertyValueFactory<>("shift1Hours"));
        colShift2.setCellValueFactory(new PropertyValueFactory<>("shift2Hours"));
        colShift3.setCellValueFactory(new PropertyValueFactory<>("shift3Hours"));
        colOvertime.setCellValueFactory(new PropertyValueFactory<>("overtimeHours"));
        colLate.setCellValueFactory(new PropertyValueFactory<>("lateHours"));
        
        
       filter.setItems(FXCollections.observableArrayList("Tháng", "Quy", "Năm"));
    }
    
    public void setEmployee(Employee employee) {
        currentEmployee = employee;
        NameLabel.setText(employee.getName());
        TeamLabel.setText(employee.getTeam());
        idLabel.setText(employee.getId());

    }
    
}
