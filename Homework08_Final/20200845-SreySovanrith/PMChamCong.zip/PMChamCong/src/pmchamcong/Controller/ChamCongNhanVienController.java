package pmchamcong.Controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Callback;
import pmchamcong.Model.AttendenceRecord;
import pmchamcong.Model.Employee;

/**
 *
 * @author Srey Sovanrith
 */
public class ChamCongNhanVienController {
    @FXML
    private Button backbtn;
    
    @FXML
    private TableColumn<Employee, String> ColPhone;

    @FXML
    private TableColumn<Employee, Void> colAction;

    @FXML
    private TableColumn<Employee, Integer> colAge;

    @FXML
    private TableColumn<Employee, String> colGender;

    @FXML
    private TableColumn<Employee, String> colID;

    @FXML
    private TableColumn<Employee, String> colName;

    @FXML
    private TableColumn<Employee, String> colTeam;

    @FXML
    private TableView<Employee> employeeTable;
    
    @FXML
    private ComboBox<String> filterField;

    @FXML
    private TextField searchField;
    private ObservableList<Employee> masterData = FXCollections.observableArrayList();
    private Map<String, List<AttendenceRecord>> employeeAttendanceMap = new HashMap<>();

    @FXML
    private void handleBackButtonAction(ActionEvent event) {
        try {
            // Load the homepage FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/pmchamcong/View/HomePage.fxml"));
            Parent homepageView = loader.load();

            // Get the stage from the event source
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // Set the scene to the homepage view
            Scene scene = new Scene(homepageView, 900, 600);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace(); 
        }
    }
    
    @FXML
    private void onSearch(ActionEvent event) {
        filterData();
    }

    @FXML
    private void onFilter(ActionEvent event) {
        filterData();
    }
    
    private void filterData() {
        FilteredList<Employee> filteredData = new FilteredList<>(masterData, b -> true);
        
        filteredData.setPredicate(employee -> {
            // If no search text or filter is provided, display all employees
            if (searchField.getText().isEmpty() || searchField.getText() == null) {
                return filterField.getSelectionModel().getSelectedItem().equals("All") ||
                        employee.getGender().equals(filterField.getSelectionModel().getSelectedItem());
            }
            
            String lowerCaseSearchText = searchField.getText().toLowerCase();
            
            if (employee.getName().toLowerCase().contains(lowerCaseSearchText)) {
                return filterField.getSelectionModel().getSelectedItem().equals("All") ||
                        employee.getGender().equals(filterField.getSelectionModel().getSelectedItem());
            } else if (employee.getId().contains(searchField.getText())) {
                return filterField.getSelectionModel().getSelectedItem().equals("All") ||
                        employee.getGender().equals(filterField.getSelectionModel().getSelectedItem());
            } else {
                return false;
            }
        });
        
        SortedList<Employee> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(employeeTable.comparatorProperty());
        employeeTable.setItems(sortedData);
        employeeTable.refresh();
    }
    
    public void initialize() {
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colID.setCellValueFactory(new PropertyValueFactory<>("id"));
        colGender.setCellValueFactory(new PropertyValueFactory<>("gender"));
        colAge.setCellValueFactory(new PropertyValueFactory<>("age"));
        ColPhone.setCellValueFactory(new PropertyValueFactory<>("phone"));
        colTeam.setCellValueFactory(new PropertyValueFactory<>("team"));
        
        setupStringColumn(colName, "name");
        setupStringColumn(colID, "id");
        setupStringColumn(colGender, "gender");
        setupIntegerColumn(colAge, "age");
        setupStringColumn(ColPhone, "phone");
        setupStringColumn(colTeam, "team");

        
        // setup the action button
         colAction.setCellFactory(new Callback<TableColumn<Employee, Void>, TableCell<Employee, Void>>() {
            @Override
            public TableCell<Employee, Void> call(final TableColumn<Employee, Void> param) {
                final TableCell<Employee, Void> cell = new TableCell<Employee, Void>() {
                    private final Button btn = new Button("Chi tiết");
                    {
                        btn.setOnAction((ActionEvent event) -> {
                            Employee data = getTableView().getItems().get(getIndex());
                            showEmployeeDetails(data);
                        });
                        // move btn to center
                        btn.setMaxWidth(Double.MAX_VALUE);
                        btn.setAlignment(Pos.CENTER);
                    }
                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(btn);
                            setAlignment(Pos.CENTER);
                        }
                    }
                };
                return cell;
            }
        });
         ObservableList<Employee> employeeList = FXCollections.observableArrayList(
                 new Employee("Nguyễn Văn A", "001", "Nam", 25, "090222201", "01"),
                 new Employee("Nguyễn Văn B", "002", "Nữ", 26, "090244201", "01"),
                 new Employee("Nguyễn Văn C", "003", "Nam", 25, "090288201", "01"),
                 new Employee("Nguyễn Văn D", "004", "Nữ", 26, "090245501", "02"),
                 new Employee("Nguyễn Văn E", "005", "Nam", 25, "090200201", "01"),
                 new Employee("Nguyễn Văn F", "006", "Nữ", 26, "090244201", "03"),
                 new Employee("Nguyễn Văn G", "007", "Nam", 25, "0902552201", "01"),
                 new Employee("Nguyễn Văn H", "008", "Nữ", 26, "090245401", "01"),
                 new Employee("Nguyễn Văn A", "001", "Nam", 25, "090222201", "01"),
                 new Employee("Nguyễn Văn B", "002", "Nữ", 26, "090244201", "01"),
                 new Employee("Nguyễn Văn C", "003", "Nam", 25, "090288201", "02"),
                 new Employee("Nguyễn Văn D", "004", "Nữ", 26, "090245501", "03"),
                 new Employee("Nguyễn Văn E", "005", "Nam", 25, "090200201", "05"),
                 new Employee("Nguyễn Văn F", "006", "Nữ", 26, "090244201", "01"),
                 new Employee("Nguyễn Văn G", "007", "Nam", 25, "0902552201", "01"),
                 new Employee("Nguyễn Văn H", "008", "Nữ", 26, "090245401", "01")
         );
         employeeTable.setItems(employeeList);
         
         // Set up the filter ComboBox with options
        filterField.setItems(FXCollections.observableArrayList("All", "Nam", "Nữ"));
        filterField.getSelectionModel().selectFirst();
        
        // masterData list
        masterData.addAll(
                 new Employee("Nguyễn Văn A", "001", "Nam", 25, "090222201", "01"),
                 new Employee("Nguyễn Văn B", "002", "Nữ", 26, "090244201", "01"),
                 new Employee("Nguyễn Văn C", "003", "Nam", 25, "090288201", "01"),
                 new Employee("Nguyễn Văn D", "004", "Nữ", 26, "090245501", "02"),
                 new Employee("Nguyễn Văn E", "005", "Nam", 25, "090200201", "01"),
                 new Employee("Nguyễn Văn F", "006", "Nữ", 26, "090244201", "03"),
                 new Employee("Nguyễn Văn G", "007", "Nam", 25, "0902552201", "01"),
                 new Employee("Nguyễn Văn H", "008", "Nữ", 26, "090245401", "01"),
                 new Employee("Nguyễn Văn A", "001", "Nam", 25, "090222201", "01"),
                 new Employee("Nguyễn Văn B", "002", "Nữ", 26, "090244201", "01"),
                 new Employee("Nguyễn Văn C", "003", "Nam", 25, "090288201", "02"),
                 new Employee("Nguyễn Văn D", "004", "Nữ", 26, "090245501", "03"),
                 new Employee("Nguyễn Văn E", "005", "Nam", 25, "090200201", "05"),
                 new Employee("Nguyễn Văn F", "006", "Nữ", 26, "090244201", "01"),
                 new Employee("Nguyễn Văn G", "007", "Nam", 25, "0902552201", "01"),
                 new Employee("Nguyễn Văn H", "008", "Nữ", 26, "090245401", "01")
        ); 
        
        populateAttendanceData();
        
    }
    

   private <T> void setupStringColumn(TableColumn<Employee, T> column, String propertyName) {
    if (column != null) {
        column.setCellValueFactory(new PropertyValueFactory<>(propertyName));
        column.setCellFactory(tc -> new TableCell<Employee, T>() {
            @Override
            protected void updateItem(T item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item.toString());
                    setAlignment(Pos.CENTER);
                }
            }
        });
    }
}
   
   // for integer column to center 
   private void setupIntegerColumn(TableColumn<Employee, Integer> column, String propertyName) {
    column.setCellValueFactory(new PropertyValueFactory<>(propertyName));
    column.setCellFactory(tc -> new TableCell<Employee, Integer>() {
        @Override
        protected void updateItem(Integer item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null) {
                setText(null);
            } else {
                setText(item.toString());
                setAlignment(Pos.CENTER);
            }
        }
    });
}
   
  private void populateAttendanceData() {
        
        employeeAttendanceMap.put("001", Arrays.asList(
            new AttendenceRecord("20/11/2023", 4.0, 4.0, 4.0, 2.0, 0.0),
            new AttendenceRecord("21/11/2023", 3.0, 3.5, 4.0, 0.0, 1.0),
            new AttendenceRecord("22/11/2023", 3.0, 4.0, 4.0, 4.0, 2.0),
            new AttendenceRecord("23/11/2023", 3.0, 3.5, 4.0, 4.0, 1.0)
           
        ));
        employeeAttendanceMap.put("002", Arrays.asList(
            new AttendenceRecord("20/11/2023", 3.0, 5.0, 4.0, 5.0, 0.0),
            new AttendenceRecord("21/11/2023", 5.0, 3.5, 4.0, 0.0, 0.0),
            new AttendenceRecord("22/11/2023", 3.0, 4.0, 4.0, 4.0, 2.0),
            new AttendenceRecord("23/11/2023", 3.0, 3.5, 4.0, 4.0, 1.0)
           
        ));
        employeeAttendanceMap.put("003", Arrays.asList(
            new AttendenceRecord("20/11/2023", 3.0, 4.0, 4.0, 4.0, 2.0),
            new AttendenceRecord("21/11/2023", 3.0, 3.5, 4.0, 4.0, 1.0),
            new AttendenceRecord("22/11/2023", 4.0, 4.0, 4.0, 4.0, 2.0),
            new AttendenceRecord("23/11/2023", 0.0, 0.5, 3.0, 4.0, 1.0)
           
        ));
        employeeAttendanceMap.put("004", Arrays.asList(
            new AttendenceRecord("20/11/2023", 4.0, 5.0, 4.0, 6.0, 0.5),
            new AttendenceRecord("21/11/2023", 4.0, 2.5, 4.0, 5.0, 1.0),
            new AttendenceRecord("22/11/2023", 3.0, 4.0, 4.0, 4.0, 2.0),
            new AttendenceRecord("23/11/2023", 3.0, 3.5, 4.0, 4.0, 1.0)
           
        ));
        // more employee
    }
   
    private void showEmployeeDetails(Employee employee) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/pmchamcong/View/EmployeeDetail.fxml"));
             Parent detailView = loader.load();
            
            // Get the controller for the detail view and set the employee
            EmployeeDetail controller = loader.getController();
            controller.setEmployee(employee);
            controller.setAttendanceRecords(employeeAttendanceMap.get(employee.getId()));
          
            // Show the detail view in a new window or a dialog
            Stage stage = new Stage();
            stage.setTitle("Employee Details");
            stage.setScene(new Scene(detailView, 900, 600));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
            
    }
    
}
