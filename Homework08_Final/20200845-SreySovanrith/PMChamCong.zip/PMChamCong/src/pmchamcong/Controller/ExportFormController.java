
package pmchamcong.Controller;

import java.io.IOException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import pmchamcong.Model.Employee;

/**
 *
 * @author Srey Sovanrith
 */
public class ExportFormController {
    
    @FXML
    private TableView<Employee> ExportTable;

    @FXML
    private Button backbtn;

    @FXML
    private TableColumn<Employee, Integer> colAge;

    @FXML
    private TableColumn<Employee, String> colGender;

    @FXML
    private TableColumn<Employee, String> colID;

    @FXML
    private TableColumn<Employee, String> colName;

    @FXML
    private TableColumn<Employee, String> colPhone;

    @FXML
    private TableColumn<Employee, String> colTeam;
    
    @FXML
    private CheckBox selectAll;

    @FXML
    private TableColumn<Employee, Boolean> colSelect;
    @FXML
    private ComboBox<String> exportOption;
    
    private ObservableList<Employee> employeeList = FXCollections.observableArrayList();

    @FXML
    private void handleBackButtonAction(ActionEvent event) {
        try {
            // Load the homepage FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/pmchamcong/View/HomePage.fxml"));
            Parent homepageView = loader.load();

            // Get the stage from the event source
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // Set the scene to the homepage view
            Scene scene = new Scene(homepageView);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace(); 
        }
    }
    
    public void initialize() {
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colID.setCellValueFactory(new PropertyValueFactory<>("id"));
        colGender.setCellValueFactory(new PropertyValueFactory<>("gender"));
        colAge.setCellValueFactory(new PropertyValueFactory<>("age"));
        colPhone.setCellValueFactory(new PropertyValueFactory<>("phone"));
        colTeam.setCellValueFactory(new PropertyValueFactory<>("team"));
        
        
        initializeEmployeeList();
//        ObservableList<Employee> employeeList = getEmployee();
        
        ExportTable.setItems(employeeList);
        ExportTable.setEditable(true);
        colSelect.setEditable(true);
        exportOption.setItems(FXCollections.observableArrayList("Excel", "CSV"));
        colSelect.setCellFactory(CheckBoxTableCell.forTableColumn(colSelect));
        colSelect.setCellValueFactory(cellData -> cellData.getValue().selectedProperty());

        selectAll.setOnAction(event -> {
            boolean isSelected = selectAll.isSelected();
            ExportTable.getItems().forEach(employee -> employee.setSelected(isSelected));
        });
        // Listen to changes in each employee's selectedProperty to update the selectAllCheckbox
        for (Employee emp : ExportTable.getItems()) {
            emp.selectedProperty().addListener((obs, wasSelected, isSelected) -> {
                if (!isSelected) {
                    selectAll.setSelected(false);
                } else {
                    boolean allSelected = ExportTable.getItems().stream().allMatch(Employee::isSelected);
                    selectAll.setSelected(allSelected);
                }
            });

        }
    }
    private void initializeEmployeeList() {
        employeeList.addAll(
             new Employee("Nguyễn Văn A", "001", "Nam", 25, "090222201", "01"),
                 new Employee("Nguyễn Văn B", "002", "Nữ", 26, "090244201", "01"),
                 new Employee("Nguyễn Văn C", "003", "Nam", 25, "090288201", "01"),
                 new Employee("Nguyễn Văn D", "004", "Nữ", 26, "090245501", "02"),
                 new Employee("Nguyễn Văn E", "005", "Nam", 25, "090200201", "01"),
                 new Employee("Nguyễn Văn F", "006", "Nữ", 26, "090244201", "03"),
                 new Employee("Nguyễn Văn G", "007", "Nam", 25, "0902552201", "01"),
                 new Employee("Nguyễn Văn H", "008", "Nữ", 26, "090245401", "01"),
                 new Employee("Nguyễn Văn A", "001", "Nam", 25, "090222201", "01"),
                 new Employee("Nguyễn Văn B", "002", "Nữ", 26, "090244201", "01"),
                 new Employee("Nguyễn Văn C", "003", "Nam", 25, "090288201", "02"),
                 new Employee("Nguyễn Văn D", "004", "Nữ", 26, "090245501", "03"),
                 new Employee("Nguyễn Văn E", "005", "Nam", 25, "090200201", "05"),
                 new Employee("Nguyễn Văn F", "006", "Nữ", 26, "090244201", "01"),
                 new Employee("Nguyễn Văn G", "007", "Nam", 25, "0902552201", "01"),
                 new Employee("Nguyễn Văn H", "008", "Nữ", 26, "090245401", "01")
        );
    }
    
   
}
