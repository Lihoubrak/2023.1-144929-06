/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pmchamcong.Controller;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 *
 * @author Srey Soovanrith
 */
public class ChamCongToanBo {
    @FXML
    private Button backbtn;
    @FXML
    private Button team1Btn;

    @FXML
    private Button team2Btn;

    @FXML
    private Button team3Btn;

    @FXML
    private Button team4Btn;

    @FXML
    private Button team5Btn;
    
    // handle back to homepage
    @FXML
    private void handleBackButtonAction(ActionEvent event) {
        try {
            // Load the homepage FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/pmchamcong/View/HomePage.fxml"));
            Parent homepageView = loader.load();

            // Get the stage from the event source
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // Set the scene to the homepage view
            Scene scene = new Scene(homepageView);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace(); 
        }
    }
    
    @FXML
    private void handleTeam1Action(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/pmchamcong/View/Team1.fxml"));
            Parent Team1Page = loader.load();
             
            Scene scene = new Scene(Team1Page);
            // get stage from event source
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            
            // change the scene on the stage 
            stage.setScene(scene);
            stage.show();
            
        } catch (Exception e) {
            e.printStackTrace();
    }
}
}
