
package pmchamcong.Controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Callback;
import pmchamcong.Model.Team1AttendanceRecord;
import pmchamcong.Model.Team1List;

/**
 *
 * @author Srey Sovanrith
 */
public class Team1Controller {
    @FXML
    private TableView<Team1List> Team1table;

    @FXML
    private Button backbtn;

    @FXML
    private TableColumn<Team1List, Void> colAction;

    @FXML
    private TableColumn<Team1List, Integer> colAge;

    @FXML
    private TableColumn<Team1List, String> colGender;

    @FXML
    private TableColumn<Team1List, String> colID;

    @FXML
    private TableColumn<Team1List, String> colName;

    @FXML
    private TableColumn<Team1List, String> colPhone;

    @FXML
    private TableColumn<Team1List, String> colTeam;

    @FXML
    private ComboBox<String> filterField;

    @FXML
    private TextField searchField;
    
    private ObservableList<Team1List> masterData = FXCollections.observableArrayList();
    private Map<String, List<Team1AttendanceRecord>> team1AttendanceMap = new HashMap<>();
    
    // handle back to team1
    @FXML
    private void handleBackButtonAction(ActionEvent event) {
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/pmchamcong/View/ChamCongToanBo.fxml"));
            Parent team1page = loader.load();

            // Get the stage from the event source
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            Scene scene = new Scene(team1page);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace(); 
        }
    }
    
    public void initialize() {
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colID.setCellValueFactory(new PropertyValueFactory<>("id"));
        colGender.setCellValueFactory(new PropertyValueFactory<>("gender"));
        colAge.setCellValueFactory(new PropertyValueFactory<>("age"));
        colPhone.setCellValueFactory(new PropertyValueFactory<>("phone"));
        colTeam.setCellValueFactory(new PropertyValueFactory<>("team"));
        
        // setup the action button
        colAction.setCellFactory(new Callback<TableColumn<Team1List, Void>, TableCell<Team1List, Void>>() {
            @Override
            public TableCell<Team1List, Void> call(final TableColumn<Team1List, Void> param) {
                final TableCell<Team1List, Void> cell = new TableCell<Team1List, Void>() {
                    private final Button btn = new Button("Chi tiết");
                    {
                        btn.setOnAction((ActionEvent event) -> {
                            Team1List data = getTableView().getItems().get(getIndex());
                            showTeam1Details(data);
                        });
                        // move btn to center
                        btn.setMaxWidth(Double.MAX_VALUE);
                        btn.setAlignment(Pos.CENTER);
                    }
                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(btn);
                            setAlignment(Pos.CENTER);
                        }
                    }
                };
                return cell;
            }
        });
         
        // set value to table
        ObservableList<Team1List> team1list = FXCollections.observableArrayList(
                new Team1List("Nguyễn Văn A", "001", "Nam", 25, "090222201", "01"),
                new Team1List("Nguyễn Văn B", "002", "Nữ", 23, "090222241", "01"),
                new Team1List("Nguyễn Văn C", "003", "Nam", 26, "090225500", "01"),
                new Team1List("Nguyễn Văn D", "004", "Nữ", 30, "094222299", "01"),
                new Team1List("Nguyễn Văn E", "005", "Nam", 25, "090223401", "01"),
                new Team1List("Nguyễn Văn F", "006", "Nữ", 23, "090222241", "01"),
                new Team1List("Nguyễn Văn G", "007", "Nam", 26, "090222200", "01"),
                new Team1List("Nguyễn Văn H", "008", "Nữ", 30, "0942222954", "01")
        );
        Team1table.setItems(team1list);
        filterField.setItems(FXCollections.observableArrayList("All", "Nam", "Nữ"));
        filterField.getSelectionModel().selectFirst();
        // filter and search data ==> chua hoan thien
//        masterData.addAll(
//                new Team1List("Nguyễn Văn A", "001", "Nam", 25, "090222201", "01"),
//                new Team1List("Nguyễn Văn B", "002", "Nữ", 23, "090222241", "01"),
//                new Team1List("Nguyễn Văn C", "003", "Nam", 26, "090222200", "01"),
//                new Team1List("Nguyễn Văn D", "004", "Nữ", 30, "094222299", "01")
//        );
        populateAttendanceDataTeam1();
    }
    
    private void populateAttendanceDataTeam1() {
        team1AttendanceMap.put("001", Arrays.asList(
                new Team1AttendanceRecord("20/11/2023", 4.0, 4.0, 4.0, 2.0, 0.0),
                new Team1AttendanceRecord("21/11/2023", 3.0, 3.0, 4.0, 2.0, 0.0)
        ));
        team1AttendanceMap.put("002", Arrays.asList(
                new Team1AttendanceRecord("20/11/2023", 3.0, 3.0, 3.0, 2.0, 0.0),
                new Team1AttendanceRecord("21/11/2023", 3.0, 3.0, 4.0, 2.0, 0.0)
        ));
        team1AttendanceMap.put("003", Arrays.asList(
                new Team1AttendanceRecord("20/11/2023", 4.0, 4.0, 4.0, 2.0, 0.0),
                new Team1AttendanceRecord("21/11/2023", 0.0, 2.0, 4.0, 2.0, 1.0)
        ));
        team1AttendanceMap.put("004", Arrays.asList(
                new Team1AttendanceRecord("20/11/2023", 3.0, 4.0, 4.0, 2.0, 1.0),
                new Team1AttendanceRecord("21/11/2023", 2.0, 3.0, 4.0, 2.0, 1.0)
        ));
        team1AttendanceMap.put("005", Arrays.asList(
                new Team1AttendanceRecord("20/11/2023", 3.0, 3.0, 3.0, 2.0, 0.0),
                new Team1AttendanceRecord("21/11/2023", 3.0, 3.0, 4.0, 2.0, 0.0)
        ));
        team1AttendanceMap.put("006", Arrays.asList(
                new Team1AttendanceRecord("20/11/2023", 0.0, 4.0, 4.0, 2.0, 0.0),
                new Team1AttendanceRecord("21/11/2023", 1.0, 4.0, 4.0, 2.0, 1.0)
        ));
    }
    
    private void showTeam1Details(Team1List employee) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/pmchamcong/View/Team1Detail.fxml"));
             Parent team1detail = loader.load();
            
            Team1DetailController controller = loader.getController();
            controller.setEmployee(employee);
            controller.setAttendanceRecords(team1AttendanceMap.get(employee.getId()));
            
            Stage stage = new Stage();
            stage.setTitle("Team 1 Details");
            stage.setScene(new Scene(team1detail));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
            
    }
}
