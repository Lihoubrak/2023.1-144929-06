
package pmchamcong.Model;

/**
 *
 * @author Srey Sovanrith
 */
public class Team1AttendanceRecord {
    private String day;
    private double shift1Hours;
    private double shift2Hours;
    private double shift3Hours;
    private double overtimeHours;
    private double lateHours;
    
    public Team1AttendanceRecord(String day, double shift1Hours, double shift2Hours, double shift3Hours, double overtimeHours, double lateHours) {
        this.day = day;
        this.shift1Hours = shift1Hours;
        this.shift2Hours = shift2Hours;
        this.shift3Hours = shift3Hours;
        this.overtimeHours = overtimeHours;
        this.lateHours = lateHours;
    }
    public String getDay() { return day; }
    public double getShift1Hours() { return shift1Hours; }
    public double getShift2Hours() { return shift2Hours; }
    public double getShift3Hours() { return shift3Hours; }
    public double getOvertimeHours() { return overtimeHours; }
    public double getLateHours() { return lateHours; }
    
    public void setDate(String day) { this.day = day; }
    public void setShift1Hours(double shift1Hours) { this.shift1Hours = shift1Hours; }
    public void setShift2Hours(double shift2Hours) { this.shift2Hours = shift2Hours; }
    public void setShift3Hours(double shift3Hours) { this.shift3Hours = shift3Hours; }
    public void setOvertimeHours(double overtimeHours) { this.overtimeHours = overtimeHours; }
    public void setLateHours(double lateHours) { this.lateHours = lateHours; }
}
