package pmchamcong.Model;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;



/**
 *
 * @author Srey Sovanrith
 */
public class Employee {
    private final StringProperty name;
    private final StringProperty id;
    private final StringProperty gender;
    private final IntegerProperty age;
    private final StringProperty phone;
    private final StringProperty team;
    private final BooleanProperty selected = new SimpleBooleanProperty(false);

    public Employee(String name, String id, String gender, int age, String phone, String team) {
        this.name = new SimpleStringProperty(name);
        this.id = new SimpleStringProperty(id);
        this.gender = new SimpleStringProperty(gender);
        this.age = new SimpleIntegerProperty(age);
        this.phone = new SimpleStringProperty(phone);
        this.team = new SimpleStringProperty(team);
    }

    public String getName() {
        return name.get();
    }

    public void setName(String value) {
        name.set(value);
    }

    public StringProperty nameProperty() {
        return name;
    }

    public String getId() {
        return id.get();
    }

    public void setId(String value) {
        id.set(value);
    }

    public StringProperty idProperty() {
        return id;
    }

    public String getGender() {
        return gender.get();
    }

    public void setGender(String value) {
        gender.set(value);
    }

    public StringProperty genderProperty() {
        return gender;
    }

    public int getAge() {
        return age.get();
    }

    public void setAge(int value) {
        age.set(value);
    }

    public IntegerProperty ageProperty() {
        return age;
    }

    public String getPhone() {
        return phone.get();
    }

    public void setPhone(String value) {
        phone.set(value);
    }

    public StringProperty phoneProperty() {
        return phone;
    }

    public String getTeam() {
        return team.get();
    }

    public void setTeam(String value) {
        team.set(value);
    }

    public StringProperty teamProperty() {
        return team;
    }
    
    public BooleanProperty selectedProperty() {
        return selected;
    }
    
    public boolean isSelected() {
        return selected.get();
    }

    public void setSelected(boolean selected) {
        this.selected.set(selected);
    }
}
