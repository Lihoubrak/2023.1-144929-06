package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class InputinformationController {
	@FXML
	private Button btnsearch,btnback;
	private String condition;
	
	public String isCondition() {
		return condition;
	}


	public void setCondition(String condition) {
		this.condition = condition;
	}


	@FXML
	private void Search(ActionEvent event) throws IOException {
	     // Replace this with your actual condition

	    // Load the FXML file for the new scene
	    FXMLLoader loader;
	    if (this.isCondition()=="a") {
	        loader = new FXMLLoader(getClass().getResource("Chamcongnhanvien.fxml"));
	    } else {
	        loader = new FXMLLoader(getClass().getResource("Xuatbanghi.fxml"));
	    }

	    // Load the FXML file and set the controller
	    Parent root = loader.load();

	

	    // Create a new scene with the loaded FXML file
	    Scene otherScene = new Scene(root);

	    // Get the stage information
	    Stage stage = (Stage) btnsearch.getScene().getWindow();

	    // Set the new scene on the stage
	    stage.setScene(otherScene);

	    // Show the stage with the new scene
	    stage.show();
	}

	 
	 @FXML
	 private void Back() throws IOException {
		  // Load the FXML file for the new scene
	     FXMLLoader loader = new FXMLLoader(getClass().getResource("Mayquetvantay.fxml"));
	     Parent root = loader.load();
	     // Get the stage information
	     Stage stage = (Stage)  btnback.getScene().getWindow();
	     Scene otherScene = new Scene(root);
	     // Set the new scene on the stage
	     stage.setScene(otherScene);

	     // Show the stage with the new scene
	     stage.show();
	 }
}
