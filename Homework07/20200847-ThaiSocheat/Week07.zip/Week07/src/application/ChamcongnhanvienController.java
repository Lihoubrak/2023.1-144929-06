package application;


import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class ChamcongnhanvienController {
	
	private Stage stage;
	private Scene scene;
	private Parent root;
	@FXML
	private Button btnbackthree;
	
	@FXML
	 private void xuatfile (ActionEvent event) throws IOException {
	     // Load the FXML file for the new scene
	     FXMLLoader loader = new FXMLLoader(getClass().getResource("InputInformation.fxml"));
	     Parent root = loader.load();

	     // Create a new scene with the loaded FXML file
	     Scene otherScene = new Scene(root);

	     // Get the stage information
	     Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

	     // Set the new scene on the stage
	     stage.setScene(otherScene);

	     // Show the stage with the new scene
	     stage.show();
	 }

	
	
	
	
	
	
	
	public void switchToScene1(ActionEvent event) throws IOException {
		  root = FXMLLoader.load(getClass().getResource("InputInformation.fxml"));
		  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		  scene = new Scene(root);
		  stage.setScene(scene);
		  stage.show();
		 }
		 
		 public void switchToScene2(ActionEvent event) throws IOException {
		  Parent root = FXMLLoader.load(getClass().getResource("Chamcongnhanvien.fxml"));
		  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		  scene = new Scene(root);
		  stage.setScene(scene);
		  stage.show();
		 }
	 @FXML
 private void handleBack() throws IOException {
     FXMLLoader loader = new FXMLLoader(getClass().getResource("InputInformation.fxml"));
     Parent root = loader.load();
     // Get the stage information
     Stage stage = (Stage)  btnbackthree.getScene().getWindow();
     Scene otherScene = new Scene(root);
     // Set the new scene on the stage
     stage.setScene(otherScene);

     // Show the stage with the new scene
     stage.show();
 }
}
