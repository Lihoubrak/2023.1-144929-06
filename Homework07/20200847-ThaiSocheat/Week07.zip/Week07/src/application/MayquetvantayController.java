package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class MayquetvantayController {

 private Stage stage;
 private Scene scene;
 private Parent root;
 @FXML
 private Button btnsearch;
 @FXML
 private Button btnback;
 @FXML 
 private Button btnbackthree;
 
 @FXML
 
 private Button btnxembanghi;
 
 @FXML
 private Button btnbackfour;

 // ... (other methods and fields)
 
 public class NextController {

	   // click on this button to jump back to the previous home scene
	    @FXML
	 	private void Back() throws IOException {
	        FXMLLoader loader = new FXMLLoader(getClass().getResource("InputInformation.fxml"));
	        Parent root = loader.load();
	        // Get the stage information
	        Stage stage = (Stage)  btnback.getScene().getWindow();
	        Scene otherScene = new Scene(root);
	        // Set the new scene on the stage
	        stage.setScene(otherScene);

	        // Show the stage with the new scene
	        stage.show();
	 	}
	    @FXML
//	 	private void xuatbanghi() {
//	 		
//	 	}
	   
	    private Scene preScene;

	    public void setPreScene(Scene preScene) {
	        this.preScene = preScene;
	    }

	    @FXML
	    void onClickBack(ActionEvent event) throws IOException {
	        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	        stage.setScene(preScene);
	        stage.show();
	    }

	}
 


  @FXML
 private void input() {}
 

 @FXML
 private void xembanghi(ActionEvent event) throws IOException {
     // Load the FXML file for the new scene
     FXMLLoader loader = new FXMLLoader(getClass().getResource("InputInformation.fxml"));
     Parent root = loader.load();

     // Create a new scene with the loaded FXML file
     Scene otherScene = new Scene(root);
    InputinformationController controller = loader.getController();
    controller.setCondition("a");
     // Get the stage information
     Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

     // Set the new scene on the stage
     stage.setScene(otherScene);

     // Show the stage with the new scene
     stage.show();
 }
 
 @FXML
 private void xuatfile (ActionEvent event) throws IOException {
     // Load the FXML file for the new scene
     FXMLLoader loader = new FXMLLoader(getClass().getResource("InputInformation.fxml"));
     Parent root = loader.load();

     // Create a new scene with the loaded FXML file
     Scene otherScene = new Scene(root);

     // Get the stage information
     Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
     // Set the new scene on the stage
     stage.setScene(otherScene);

     // Show the stage with the new scene
     stage.show();
 }




public void switchToScene1(ActionEvent event) throws IOException {
  root = FXMLLoader.load(getClass().getResource("Mayquetvantay.fxml"));
  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
  scene = new Scene(root);
  stage.setScene(scene);
  stage.show();
 }
 
 public void switchToScene2(ActionEvent event) throws IOException {
  Parent root = FXMLLoader.load(getClass().getResource("InputInformation.fxml"));
  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
  scene = new Scene(root);
  stage.setScene(scene);
  stage.show();
 }
}