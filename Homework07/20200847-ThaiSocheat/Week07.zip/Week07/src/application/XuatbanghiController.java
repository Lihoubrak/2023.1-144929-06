package application;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class XuatbanghiController {
    private boolean check;
    private boolean check2;
    @FXML
    private Button btnbackfour;

    public boolean isCheck() {
        return check;
    }

    public boolean isCheck2() {
		return check2;
	}

	public void setCheck2(boolean check2) {
		this.check2 = check2;
		 if (check2) {
			 displaySample3Scene();
	        }
	}

	public void setCheck(boolean check) {
    	System.out.println(check);
        this.check = check;
        if (check) {
            displaySample4Scene();
        }
    }

    private void displaySample4Scene() {
        try {
            // Load the FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Xuatbanghi.fxml"));
            Parent root = loader.load();

            // Create a new scene
            Scene scene = new Scene(root);

            // Create a new stage
            Stage stage = new Stage();
            stage.setScene(scene);

            // Show the stage
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            // Handle the exception appropriately
        }
    }
    private void displaySample3Scene() {
        try {
            // Load the FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Chamcongnhanvien.fxml"));
            Parent root = loader.load();

            // Create a new scene
            Scene scene = new Scene(root);

            // Create a new stage
            Stage stage = new Stage();
            stage.setScene(scene);

            // Show the stage
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            // Handle the exception appropriately
        }
    }
    @FXML
    private void forBack() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("InputInformation.fxml"));
        Parent root = loader.load();

        // Get the stage information
        Stage stage = (Stage) btnbackfour.getScene().getWindow();

        // Get the current scene and update its root
        Scene currentScene = stage.getScene();
        currentScene.setRoot(root);

        // Show the stage with the updated scene
        stage.show();
    }

}
