package Test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javafx.embed.swing.JFXPanel;  // Import JFXPanel
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import javafx.scene.control.Button;
import model.Employee;
import model.WorkDetail;
import model.Worker;

class WorkerTest {

    @BeforeAll
    public static void initJFX() {
        // Initialize JavaFX toolkit
        JFXPanel jfxPanel = new JFXPanel();
    }

    @Test
    public void testWorkerInheritsFromEmployee() {
        // Create test data
        int employeeID = 123;
        String name = "John Doe";
        String department = "IT";
        String position = "Software Engineer";
        Button button = new Button("ADD");
        List<WorkDetail> workDetails = List.of(
                new WorkDetail(LocalDate.of(2022, 1, 5), "casang", 1, 3, "4", "2", "5", "4", "4", "5")
        );

        // Create Worker object
        Worker worker = new Worker(employeeID, name, department, position, button, workDetails);

        // Assert that Worker is an instance of Employee
        assertTrue(worker instanceof Employee);
    }

    @Test
    public void testWorkerConstructor() {
        // Create test data
        int employeeID = 123;
        String name = "Jane Doe";
        String department = "Marketing";
        String position = "Marketing Manager";
        Button button = new Button("View Details");
        List<WorkDetail> workDetails = List.of(
                new WorkDetail(LocalDate.of(2022, 1, 5), "casang", 1, 3, "4", "2", "5", "4", "4", "5")
        );


        // Create Worker object
        Worker worker = new Worker(employeeID, name, department, position, button, workDetails);

        // Assert values inherited from Employee
        assertEquals(employeeID, worker.getEmployeeID());
        assertEquals(name, worker.getName());
        assertEquals(department, worker.getDepartment());
        assertEquals(position, worker.getPosition());
        assertEquals(button, worker.getButton());
        assertEquals(workDetails, worker.getWorkDetails());
    }
}
