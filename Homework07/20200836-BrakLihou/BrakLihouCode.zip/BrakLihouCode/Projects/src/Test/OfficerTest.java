package Test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import javafx.embed.swing.JFXPanel;
import javafx.scene.control.Button;
import model.Officer;
import model.WorkDetail;

class OfficerTest {
	@BeforeAll
    public static void initJFX() {
        // Initialize JavaFX toolkit
        JFXPanel jfxPanel = new JFXPanel();
    }
	@Test
    public void testConstructor_ValidArguments() {
        // Arrange
        int employeeID = 1234;
        String name = "John Doe";
        String department = "HR";
        String position = "Manager";
        Button button = new Button("Assign Work");
        List<WorkDetail> workDetails = List.of(
                new WorkDetail(LocalDate.of(2022, 1, 5), "casang", 1, 3, "4", "2", "5", "4", "4", "5")
        );
        // Act
        Officer officer = new Officer(employeeID, name, department, position, button, workDetails);

        // Assert
        assertEquals(employeeID, officer.getEmployeeID());
        assertEquals(name, officer.getName());
        assertEquals(department, officer.getDepartment());
        assertEquals(position, officer.getPosition());
        assertEquals(button, officer.getButton());
        assertEquals(workDetails, officer.getWorkDetails());
    }


}
