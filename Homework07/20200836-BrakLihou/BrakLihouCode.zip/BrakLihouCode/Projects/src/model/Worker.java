package model;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import javafx.scene.control.Button;
import java.time.DayOfWeek;
public class Worker extends Employee {
    public Worker(int employeeID, String name, String department, String position,Button button ,List<WorkDetail> workDetails) {
        super(employeeID, name, department, position,  button, workDetails);
    }
}
