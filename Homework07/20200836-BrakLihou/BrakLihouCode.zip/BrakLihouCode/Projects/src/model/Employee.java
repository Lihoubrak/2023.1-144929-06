package model;

import javafx.scene.control.Button;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public class Employee {

    private int employeeID;
    private String name;
    private String department;
    private String position;
    private Button button; 
    private List<WorkDetail> workDetails;
    
	public Employee(int employeeID, String name, String department, String position, Button button,
			List<WorkDetail> workDetails) {
		super();
		this.employeeID = employeeID;
		this.name = name;
		this.department = department;
		this.position = position;
		this.button = button;
		this.workDetails = workDetails;
	}
	public int getEmployeeID() {
		return employeeID;
	}
	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public Button getButton() {
		return button;
	}
	public void setButton(Button button) {
		this.button = button;
	}
	public List<WorkDetail> getWorkDetails() {
		return workDetails;
	}
	public void setWorkDetails(List<WorkDetail> workDetails) {
		this.workDetails = workDetails;
	}
    
}
